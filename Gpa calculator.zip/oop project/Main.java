import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

abstract class Person {
    protected String name;
    protected String email;

    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Getters and setters for name and email
    public String getName() { return name; }
    public String getEmail() { return email; }
}

class Student extends Person {
    private String uniName;
    private String course;
    private String problem;

    public Student(String name, String email, String uniName, String course, String problem) {
        super(name, email);
        this.uniName = uniName;
        this.course = course;
        this.problem = problem;
    }

    // Getters and setters for uniName, course, and problem
    public String getUniName() { return uniName; }
    public String getCourse() { return course; }
    public String getProblem() { return problem; }

    @Override
    public String toString() {
        return name + "," + email + "," + uniName + "," + course + "," + problem;
    }
}

class Helper extends Person {
    private String completedCourses;
    private String uniName;

    public Helper(String name, String email, String completedCourses, String uniName) {
        super(name, email);
        this.completedCourses = completedCourses;
        this.uniName = uniName;
    }

    // Getters and setters for completedCourses and uniName
    public String getCompletedCourses() { return completedCourses; }
    public String getUniName() { return uniName; }

    @Override
    public String toString() {
        return name + "," + email + "," + completedCourses + "," + uniName;
    }
}

public class Main {
    private static final String STUDENTS_FILE = "students.txt";
    private static final String HELPERS_FILE = "helpers.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Are you a Student or a Helper? (Enter 'student' or 'helper')");
        String userType = scanner.nextLine().trim().toLowerCase();

        if (userType.equals("student")) {
            handleStudent(scanner);
        } else if (userType.equals("helper")) {
            handleHelper(scanner);
        } else {
            System.out.println("Invalid input. Please restart the program and enter 'student' or 'helper'.");
        }

        scanner.close();
    }

    private static void handleStudent(Scanner scanner) {
        System.out.println("Enter your name:");
        String name = scanner.nextLine();
        System.out.println("Enter your email:");
        String email = scanner.nextLine();
        System.out.println("Enter your university name:");
        String uniName = scanner.nextLine();
        System.out.println("Enter your course:");
        String course = scanner.nextLine();
        System.out.println("Describe your problem:");
        String problem = scanner.nextLine();

        Student student = new Student(name, email, uniName, course, problem);
        saveStudent(student);
        System.out.println("Student details saved.");

        List<Helper> matchingHelpers = findMatchingHelpers(uniName, course);
        if (matchingHelpers.isEmpty()) {
            System.out.println("No helpers found for your university and course.");
        } else {
            System.out.println("Here are some helpers who can assist you:");
            for (Helper helper : matchingHelpers) {
                System.out.println(helper.getName() + " - " + helper.getEmail());
            }
        }
    }

    private static void handleHelper(Scanner scanner) {
        System.out.println("Enter your name:");
        String name = scanner.nextLine();
        System.out.println("Enter your email:");
        String email = scanner.nextLine();
        System.out.println("Enter the courses you have completed:");
        String completedCourses = scanner.nextLine();
        System.out.println("Enter your university name:");
        String uniName = scanner.nextLine();

        Helper helper = new Helper(name, email, completedCourses, uniName);
        saveHelper(helper);
        System.out.println("Helper details saved.");
    }

    private static void saveStudent(Student student) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(STUDENTS_FILE, true))) {
            writer.write(student.toString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("An error occurred while saving student details: " + e.getMessage());
        }
    }

    private static void saveHelper(Helper helper) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(HELPERS_FILE, true))) {
            writer.write(helper.toString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("An error occurred while saving helper details: " + e.getMessage());
        }
    }

    private static List<Helper> findMatchingHelpers(String uniName, String course) {
        List<Helper> matchingHelpers = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(HELPERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] details = line.split(",");
                if (details.length == 4) {
                    String name = details[0];
                    String email = details[1];
                    String completedCourses = details[2];
                    String helperUniName = details[3];

                    if (helperUniName.equalsIgnoreCase(uniName) && completedCourses.toLowerCase().contains(course.toLowerCase())) {
                        matchingHelpers.add(new Helper(name, email, completedCourses, helperUniName));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading helper details: " + e.getMessage());
        }
        return matchingHelpers;
    }
}
